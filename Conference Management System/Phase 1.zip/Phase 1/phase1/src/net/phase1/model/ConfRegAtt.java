package net.phase1.model;



import java.io.Serializable;


public class ConfRegAtt implements Serializable {
	private static final long serialVersionUID = 1L;

	private String conf_name;
	private String att_name;
	private String att_email;
	private String att_phno;
	
	public void setConfName(String conf_name) {
		this.conf_name = conf_name;
	}
	public String getConfName() {
		return conf_name;
	}
	
	public void setAtteName(String att_name) {
		this.att_name = att_name;
	}
	public String getAtteName() {
		return att_name;
	}
	
	public void setAtteEmail(String att_email) {
		this.att_email = att_email;
	}
	public String getAtteEmail() {
		return att_email;
	}
	
	public void setAttePhno(String att_phno) {
		this.att_phno = att_phno;
	}
	public String getAttePhno() {
		return att_phno;
	}	

}

