package net.phase1.model;

import java.io.Serializable;


public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	private String o_email;
	private String a_email;
	private String o_name;
	private String a_name;
	private String o_password;
	private String a_password;
	private String o_phno;
	private String a_phno;
	private String c_name;
	private String url;
	private String con_name;
	private String con_description;
	private String con_date;
	private String con_venue;
	private String con_max_ppl;
	private String con_link;

	private String username;
	private String password;
	private String value;
	
	
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	//organizer 
	
	public String getOrgName() {
		return o_name;
	}
	public void setOrgName(String o_name) {
		this.o_name = o_name;
	}
	public String getOrgEmail() {
		return o_email;
	}
	public void setOrgEmail(String o_email) {
		this.o_email = o_email;
	}public String getOrgPassword() {
		return o_password;
	}
	public void setOrgPassword(String o_password) {
		this.o_password = o_password;
	}
	public String getCompanyName() {
		return c_name;
	}
	public void setCompanyName(String c_name) {
		this.c_name = c_name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getOrgPhno() {
		return o_phno;
	}
	public void setOrgPhno(String o_phno) {
		this.o_phno = o_phno;
	}
	
	//Attendee
	public String getAttName() {
		return a_name;
	}
	public void setAttName(String a_name) {
		this.a_name = a_name;
	}
	public String getAttEmail() {
		return a_email;
	}
	public void setAttEmail(String a_email) {
		this.a_email = a_email;
	}
	public String getAttPassword() {
		return a_password;
	}
	public void setAttPassword(String a_password) {
		this.a_password = a_password;
	}
	public String getAttPhno() {
		return a_phno;
	}
	public void setAttPhno(String a_phno) {
		this.a_phno = a_phno;
	}
	
//	conference
	public String getConName() {
		return con_name;
	}
	public void setConName(String con_name) {
		this.con_name = con_name;
	}
	public String getConDescription() {
		return con_description;
	}
	public void setConDescription(String con_description) {
		this.con_description = con_description;
	}
	public String getConDate() {
		return con_date;
	}
	public void setConDate(String con_date) {
		this.con_date = con_date;
	}
	public String getConVenue() {
		return con_venue;
	}
	public void setConVenue(String con_venue) {
		this.con_venue = con_venue;
	}
	public String getConMaxppl() {
		return con_max_ppl;
	}
	public void setConMaxppl(String con_max_ppl) {
		this.con_max_ppl = con_max_ppl;
	}
	public String getConLink() {
		return con_link;
	}
	public void setConLink(String con_link ) {
		this.con_link = con_link;
	}
	
	
	
	
	

}
