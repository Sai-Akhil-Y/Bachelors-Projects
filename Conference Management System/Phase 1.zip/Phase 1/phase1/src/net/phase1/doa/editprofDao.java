package net.phase1.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.phase1.database.connection.*;
import net.phase1.model.*;
//import net.javaguides.todoapp.model.User;
//import net.javaguides.todoapp.utils.JDBCUtils;

public class editprofDao {

	public int registerEmployee(User attendee) throws ClassNotFoundException {
		String UPDATE_USERS_SQL = "UPDATE attendee set a_email=?,a_password=?,a_phno=? where a_name=?;";

		int result = 0;
		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_USERS_SQL)) {
//			preparedStatement.setString(1, organizer.getFirstName());
//			preparedStatement.setString(2, organizer.getLastName());
//			preparedStatement.setString(3, organizer.getUsername());
//			preparedStatement.setString(4, organizer.getPassword());

//			preparedStatement.setString(1, attendee_update.getAttName());
			
			preparedStatement.setString(1, attendee.getAttEmail());
			preparedStatement.setString(2, attendee.getAttPassword());
			preparedStatement.setString(3, attendee.getAttPhno());
			preparedStatement.setString(4, attendee.getAttName());
			
			
//			preparedStatement.setString(5, attendee.getCompanyName());
//			preparedStatement.setString(6, attendee.getUrl());

			
			
			
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		return result;
	}

}
