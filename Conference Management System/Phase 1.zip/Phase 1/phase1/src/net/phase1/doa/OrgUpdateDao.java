package net.phase1.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.phase1.database.connection.*;
import net.phase1.model.*;
//import net.javaguides.todoapp.model.User;
//import net.javaguides.todoapp.utils.JDBCUtils;

public class OrgUpdateDao {

	public int registerEmployee(User organizer_up) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "UPDATE organizer set o_email=?,o_password=?,o_phno=? where o_name=?;";

		int result = 0;
//		String y="vijay";

		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
//			preparedStatement.setString(1, organizer.getFirstName());
//			preparedStatement.setString(2, organizer.getLastName());
//			preparedStatement.setString(3, organizer.getUsername());
//			preparedStatement.setString(4, organizer.getPassword());

			preparedStatement.setString(1, organizer_up.getOrgEmail());
			preparedStatement.setString(2, organizer_up.getOrgPassword());
			preparedStatement.setString(3, organizer_up.getOrgPhno());
			preparedStatement.setString(4, organizer_up.getOrgName());
//			preparedStatement.setString(6, x);

//			preparedStatement.setString(6, organizer.getUrl());

			
			
			
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		return result;
	}

}
