package net.phase1.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.phase1.database.connection.*;
import net.phase1.model.*;
//import net.javaguides.todoapp.model.User;
//import net.javaguides.todoapp.utils.JDBCUtils;

public class OrgUserDao {

	public int registerEmployee(User organizer) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "INSERT INTO organizer"
				+ "  (o_name, o_email, o_password, o_phno, c_name, url) VALUES "
				+ " (?, ?, ?, ?, ?, ?);";

		int result = 0;
		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
//			preparedStatement.setString(1, organizer.getFirstName());
//			preparedStatement.setString(2, organizer.getLastName());
//			preparedStatement.setString(3, organizer.getUsername());
//			preparedStatement.setString(4, organizer.getPassword());

			preparedStatement.setString(1, organizer.getOrgName());
			preparedStatement.setString(2, organizer.getOrgEmail());
			preparedStatement.setString(3, organizer.getOrgPassword());
			preparedStatement.setString(4, organizer.getOrgPhno());
			preparedStatement.setString(5, organizer.getCompanyName());
			preparedStatement.setString(6, organizer.getUrl());

			
			
			
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		return result;
	}

}
