package net.phase1.doa;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.phase1.database.connection.*;
import net.phase1.model.*;
//import net.javaguides.todoapp.model.User;
//import net.javaguides.todoapp.utils.JDBCUtils;

public class RegConfDoa {

	public int registerConference(ConfRegAtt attendee) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "INSERT INTO confreg"
				+ "  (conf_name,att_name, att_email,att_phno) VALUES "
				+ " (?, ?, ?, ?);";

		int result = 0;
		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {


			preparedStatement.setString(1, attendee.getConfName());
			preparedStatement.setString(2, attendee.getAtteName());
			preparedStatement.setString(3, attendee.getAtteEmail());
			preparedStatement.setString(4, attendee.getAttePhno());
			
			


			
			
			
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		return result;
	}

}

