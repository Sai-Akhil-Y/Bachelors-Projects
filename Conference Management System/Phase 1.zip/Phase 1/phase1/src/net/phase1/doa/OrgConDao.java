package net.phase1.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.phase1.database.connection.*;
import net.phase1.model.*;
//import net.javaguides.todoapp.model.User;
//import net.javaguides.todoapp.utils.JDBCUtils;

public class OrgConDao {

	public int registerEmployee(User organizer) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "INSERT INTO conference"
				+ "  (con_name, con_description, con_date, con_venue, con_maxppl, con_link, o_name, o_email, o_phno) VALUES "
				+ " (?, ?, ?, ?, ?, ?, ?, ?, ?);";

		int result = 0;
		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
//			preparedStatement.setString(1, organizer.getFirstName());
//			preparedStatement.setString(2, organizer.getLastName());
//			preparedStatement.setString(3, organizer.getUsername());
//			preparedStatement.setString(4, organizer.getPassword());
			
			preparedStatement.setString(1, organizer.getConName());
			preparedStatement.setString(2, organizer.getConDescription());
			preparedStatement.setString(3, organizer.getConDate());
			preparedStatement.setString(4, organizer.getConVenue());
			preparedStatement.setString(5, organizer.getConMaxppl());
			preparedStatement.setString(6, organizer.getConLink());
			preparedStatement.setString(7, organizer.getOrgName());
			preparedStatement.setString(8, organizer.getOrgEmail());
			preparedStatement.setString(9, organizer.getOrgPhno());
			
//			preparedStatement.setString(5, organizer.getCompanyName());
//			preparedStatement.setString(6, organizer.getUrl());

			
			
			
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		return result;
	}

}
