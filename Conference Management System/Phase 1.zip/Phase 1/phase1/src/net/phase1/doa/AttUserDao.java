package net.phase1.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.phase1.database.connection.*;
import net.phase1.model.*;
//import net.javaguides.todoapp.model.User;
//import net.javaguides.todoapp.utils.JDBCUtils;

public class AttUserDao {

	public int registerEmployee(User attendee) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "INSERT INTO attendee"
				+ "  (a_name, a_email, a_password, a_phno) VALUES "
				+ " (?, ?, ?, ?);";

		int result = 0;
		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
//			preparedStatement.setString(1, organizer.getFirstName());
//			preparedStatement.setString(2, organizer.getLastName());
//			preparedStatement.setString(3, organizer.getUsername());
//			preparedStatement.setString(4, organizer.getPassword());

			preparedStatement.setString(1, attendee.getAttName());
			preparedStatement.setString(2, attendee.getAttEmail());
			preparedStatement.setString(3, attendee.getAttPassword());
			preparedStatement.setString(4, attendee.getAttPhno());
			
			
//			preparedStatement.setString(5, attendee.getCompanyName());
//			preparedStatement.setString(6, attendee.getUrl());

			
			
			
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		return result;
	}

}
