package net.phase1.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;

//import net.javaguides.todoapp.dao.UserDao;
//import net.javaguides.todoapp.model.User;

@WebServlet("/conference_create_org")
public class OrgConCreateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrgConDao OrgConDao;

	public void init() {
		OrgConDao = new OrgConDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		register(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("organizer_conference/create_event.jsp");
	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String username = request.getParameter("username");
//		String password = request.getParameter("password");
		

		String con_name = request.getParameter("con_name");
		String con_description = request.getParameter("con_description");
		String con_date = request.getParameter("con_date");
		String con_venue = request.getParameter("con_venue");
		String con_max_ppl = request.getParameter("con_max_ppl");
		String con_link = request.getParameter("con_link");
		String o_name = request.getParameter("o_name");
		String o_email = request.getParameter("o_email");
//		String o_password = request.getParameter("o_password");
		String o_phno = request.getParameter("o_phno");
		
		
		

//		User employee = new User();
//		employee.setFirstName(firstName);
//		employee.setLastName(lastName);
//		employee.setUsername(username);
//		employee.setPassword(password);
	
		
		User conference = new User();
		conference.setConName(con_name);
		conference.setConDescription(con_description);
		conference.setConDate(con_date);
		conference.setConVenue(con_venue);
		conference.setConMaxppl(con_max_ppl);
		conference.setConLink(con_link);
		conference.setOrgName(o_name);
		conference.setOrgEmail(o_email);
//		organizer.setOrgPassword(o_password);
		conference.setOrgPhno(o_phno);
		
		
		
		

		try {
			int result = OrgConDao.registerEmployee(conference);
			if(result == 1) {
				
				request.setAttribute("NOTIFICATION", "User Registered Successfully!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("organizer_conference/org_view_events.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("organizer_conference/create_event.jsp");
		dispatcher.forward(request, response);
	}
}
