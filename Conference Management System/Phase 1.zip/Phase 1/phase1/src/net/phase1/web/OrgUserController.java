package net.phase1.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;

//import net.javaguides.todoapp.dao.UserDao;
//import net.javaguides.todoapp.model.User;

@WebServlet("/register_org")
public class OrgUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrgUserDao OrgUserDao;

	public void init() {
		OrgUserDao = new OrgUserDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		register(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("register/register.jsp");
	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String username = request.getParameter("username");
//		String password = request.getParameter("password");
		
		
		String o_name = request.getParameter("o_name");
		String o_email = request.getParameter("o_email");
		String o_password = request.getParameter("o_password");
		String o_phno = request.getParameter("o_phno");
		String c_name = request.getParameter("c_name");
		String url = request.getParameter("url");

		

//		User employee = new User();
//		employee.setFirstName(firstName);
//		employee.setLastName(lastName);
//		employee.setUsername(username);
//		employee.setPassword(password);
	
		
		User organizer = new User();
		organizer.setOrgName(o_name);
		organizer.setOrgEmail(o_email);
		organizer.setOrgPassword(o_password);
		organizer.setOrgPhno(o_phno);
		organizer.setCompanyName(c_name);
		organizer.setUrl(url);

		
		
		

		try {
			int result = OrgUserDao.registerEmployee(organizer);
			if(result == 1) {
				
				request.setAttribute("NOTIFICATION", "User Registered Successfully!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("login/login.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("register/register.jsp");
		dispatcher.forward(request, response);
	}
}
