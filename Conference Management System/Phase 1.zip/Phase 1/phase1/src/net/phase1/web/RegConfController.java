package net.phase1.web;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;

//import net.javaguides.todoapp.dao.UserDao;
//import net.javaguides.todoapp.model.User;

@WebServlet("/registerforConf")
public class RegConfController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RegConfDoa RegConfDoa;

	public void init() {
		RegConfDoa = new RegConfDoa();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		register(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("RegisterForConference/regForConf.jsp");
	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		

		
		
		String conf_name = request.getParameter("conf_name");
		String att_name = request.getParameter("att_name");
		String att_email = request.getParameter("att_email");
		String att_phno = request.getParameter("att_phno");

	
		
		ConfRegAtt attendee = new ConfRegAtt();
		attendee.setConfName(conf_name);
		attendee.setAtteName(att_name);
		attendee.setAtteEmail(att_email);
		attendee.setAttePhno(att_phno);
		

		
		
		

		try {
			int result = RegConfDoa.registerConference(attendee);
			if(result == 1) {
				//request.setAttribute("NOTIFICATION", "User Registered Successfully!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("ViewConference/viewConf.jsp");
				dispatcher.forward(request, response);				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("RegisterForConference/regForConf.jsp");
		dispatcher.forward(request, response);
	}
}

