package net.phase1.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;

//import net.javaguides.todoapp.dao.UserDao;
//import net.javaguides.todoapp.model.User;

@WebServlet("/update_org")
public class OrgUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrgUpdateDao OrgUpdateDao;

	public void init() {
		OrgUpdateDao = new OrgUpdateDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		register(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("update/org_update.jsp");
	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String username = request.getParameter("username");
//		String password = request.getParameter("password");
		
		
		String o_name = request.getParameter("o_name");
		String o_email = request.getParameter("o_email");
		String o_password = request.getParameter("o_password");
		String o_phno = request.getParameter("o_phno");
		String c_name = request.getParameter("c_name");
//		String url = request.getParameter("url");

		

//		User employee = new User();
//		employee.setFirstName(firstName);
//		employee.setLastName(lastName);
//		employee.setUsername(username);
//		employee.setPassword(password);
	
		
		User organizer_up = new User();
		organizer_up.setOrgName(o_name);
		organizer_up.setOrgEmail(o_email);
		organizer_up.setOrgPassword(o_password);
		organizer_up.setOrgPhno(o_phno);
		organizer_up.setCompanyName(c_name);
//		organizer.setUrl(url);

		
		
		

		try {
			int result = OrgUpdateDao.registerEmployee(organizer_up);
			if(result == 1) {
				
				request.setAttribute("NOTIFICATION", "User Registered Successfully!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("organizer_conference/org_view_events.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("update/org_update.jsp");
		dispatcher.forward(request, response);
	}
}
