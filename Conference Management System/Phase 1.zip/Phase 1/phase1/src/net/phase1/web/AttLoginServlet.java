package net.phase1.web;
import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;
import java.util.*;


import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/logincheck_att")
public class AttLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private attlogincheck attlogincheck;

	public void init() {
		
		attlogincheck = new attlogincheck();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("att");

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		User att = new User();
		att.setUsername(username);
		att.setPassword(password);

		try {
			if (attlogincheck.validate(att)) {
				//HttpSession session = request.getSession();
				// session.setAttribute("username",username);
				response.sendRedirect("RegisterForConference/regForConf.jsp");
			} else {
				HttpSession session = request.getSession();
				//session.setAttribute("user", username);
				//response.sendRedirect("login.jsp");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
