package net.phase1.web;
import java.util.*;
import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;


import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/logincheck_org")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private logincheck logincheck;

	public void init() {
		logincheck = new logincheck();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("hi");

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User User = new User();
		User.setUsername(username);
		User.setPassword(password);

		try {
			if (logincheck.validate(User)) {
				//HttpSession session = request.getSession();
				// session.setAttribute("username",username);
				response.sendRedirect("organizer_conference/create_event.jsp");
			} else {
				HttpSession session = request.getSession();
				//session.setAttribute("user", username);
				//response.sendRedirect("login.jsp");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
