package net.phase1.web;
import java.util.*;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.phase1.database.connection.*;
import net.phase1.doa.*;
import net.phase1.model.*;

//import net.javaguides.todoapp.dao.UserDao;
//import net.javaguides.todoapp.model.User;

@WebServlet("/edit_att")
public class editprofController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private editprofDao editprofDao;

	public void init() {
		editprofDao = new editprofDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		register(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("Editstudent/editstudent.jsp");
	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String username = request.getParameter("username");
//		String password = request.getParameter("password");
		
		
		String a_name = request.getParameter("a_name");
		String a_email = request.getParameter("a_email");
		String a_password = request.getParameter("a_password");
		String a_phno = request.getParameter("a_phno");
//		String c_name = request.getParameter("c_name");
//		String url = request.getParameter("url");

		

//		User employee = new User();
//		employee.setFirstName(firstName);
//		employee.setLastName(lastName);
//		employee.setUsername(username);
//		employee.setPassword(password);
	
		
		User attendee = new User();
		attendee.setAttName(a_name);
		attendee.setAttEmail(a_email);
		attendee.setAttPassword(a_password);
		attendee.setAttPhno(a_phno);
		
//		organizer.setCompanyName(c_name);
//		organizer.setUrl(url);

		
		
		

		try {
			int result = editprofDao.registerEmployee(attendee);
			if(result == 1) {
				request.setAttribute("NOTIFICATION", "Details Updated Successfully!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("ViewConference/viewConf.jsp");
				
				dispatcher.forward(request, response);				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("Editstudent/editstudent.jsp");
		dispatcher.forward(request, response);
	}
}
