-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2020 at 08:26 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phase1`
--
CREATE DATABASE IF NOT EXISTS `phase1` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `phase1`;

-- --------------------------------------------------------

--
-- Table structure for table `attendee`
--

CREATE TABLE `attendee` (
  `aid` int(10) NOT NULL,
  `a_name` varchar(50) NOT NULL,
  `a_email` varchar(50) NOT NULL,
  `a_password` varchar(20) NOT NULL,
  `a_phno` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendee`
--

INSERT INTO `attendee` (`aid`, `a_name`, `a_email`, `a_password`, `a_phno`) VALUES
(1, 'vijay', 'vijayjonathan143@gmail.com', 'vijaWED@123', 987654321),
(3, 'akhil', 'akicbhdb@gmail.com', '987654321', 987654321),
(4, 'hvdcdh', 'gahdv@gmail.com', 'QAZwsx143@', 789654123),
(5, 'new', 'newnew@gmail.com', 'QAZwsx143@', 125478963),
(6, 'attfinal', 'newfinal@gmail.com', 'QAZwsx143@', 987654321);

-- --------------------------------------------------------

--
-- Table structure for table `conference`
--

CREATE TABLE `conference` (
  `con_id` int(10) NOT NULL,
  `con_name` varchar(100) NOT NULL,
  `con_description` varchar(1000) NOT NULL,
  `con_date` varchar(50) NOT NULL,
  `con_venue` varchar(100) NOT NULL,
  `con_maxppl` varchar(50) NOT NULL,
  `con_link` varchar(500) NOT NULL,
  `o_name` varchar(100) NOT NULL,
  `o_email` varchar(100) NOT NULL,
  `o_phno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `conference`
--

INSERT INTO `conference` (`con_id`, `con_name`, `con_description`, `con_date`, `con_venue`, `con_maxppl`, `con_link`, `o_name`, `o_email`, `o_phno`) VALUES
(1, 'ckbvksbvkfvg', 'bcidbuvidbv bcdvkb', '02-12-2020', 'ameiygjb', '20', 'saljcn.com', 'vijay', 'kvmd@gmail.com', '9133140732'),
(2, 'newconf', 'asdfghjklwertyuioxcvbn', '02-12-2020', 'hyd', '20', 'adbc.com', 'suko', 'suko@gmail.com', '9874563210'),
(3, 'interview', 'for amrita students ', '08-12-2020', 'Amrita', '20', 'amrita.com', 'maya', 'maya@amrita.edu', '1236547890'),
(4, 'interview', 'for amrita students ', '08-12-2020', 'Amrita', '20', 'amrita.com', 'maya', 'maya@amrita.edu', '1236547890'),
(5, 'icpc', 'coding contest', '05-12-2020', 'amrita', '50', 'icpc.org.in', 'sumanth', 'suko@gmail.com', '4204204120');

-- --------------------------------------------------------

--
-- Table structure for table `confreg`
--

CREATE TABLE `confreg` (
  `conf_name` varchar(500) NOT NULL,
  `att_name` varchar(100) NOT NULL,
  `att_email` varchar(100) NOT NULL,
  `att_phno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confreg`
--

INSERT INTO `confreg` (`conf_name`, `att_name`, `att_email`, `att_phno`) VALUES
('icpc', 'vijay Jonathan', 'john@gmail.com', '9133140732');

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `oid` int(10) NOT NULL,
  `o_name` varchar(100) NOT NULL,
  `o_email` varchar(100) NOT NULL,
  `o_password` varchar(50) NOT NULL,
  `o_phno` varchar(50) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`oid`, `o_name`, `o_email`, `o_password`, `o_phno`, `c_name`, `url`) VALUES
(1, 'vijay', 'jon@gmail.com', 'QAZwsx143@', '987456321', 'bunny', 'bunny.com'),
(2, 'new org', 'org@gmail.com', 'QAZwsx143@', '987412563', 'amita', 'abcfg.com'),
(3, 'final', 'orgnew@gmail.com', 'QAZwsx143@', '987466321', 'final avb', 'avb.com'),
(4, 'final', 'orgnew@gmail.com', 'QAZwsx143@', '987466321', 'final avb', 'avb.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendee`
--
ALTER TABLE `attendee`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `conference`
--
ALTER TABLE `conference`
  ADD PRIMARY KEY (`con_id`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`oid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendee`
--
ALTER TABLE `attendee`
  MODIFY `aid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `conference`
--
ALTER TABLE `conference`
  MODIFY `con_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `organizer`
--
ALTER TABLE `organizer`
  MODIFY `oid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
